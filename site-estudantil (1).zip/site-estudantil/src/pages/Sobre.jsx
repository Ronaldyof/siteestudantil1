import Box from '@mui/material/Box'
import Typography from '@mui/material/Typography'
import Grid from '@mui/material/Grid'
import Card from '@mui/material/Card'
import CardContent from '@mui/material/CardContent'
import logoSrc from '../assets/logo.png'

const valores = [
  { icon: '🎯', titulo: 'Missão', desc: 'Promover educação de qualidade, formando cidadãos críticos e profissionais capacitados para o mercado de trabalho.' },
  { icon: '👁️', titulo: 'Visão', desc: 'Ser referência em ensino técnico e superior na região, reconhecida pela excelência acadêmica e inovação pedagógica.' },
  { icon: '💡', titulo: 'Valores', desc: 'Ética, respeito, inovação, inclusão e compromisso com o desenvolvimento humano e social.' },
]

const numeros = [
  { num: '1.200+', label: 'Estudantes Ativos' },
  { num: '80+', label: 'Professores' },
  { num: '12', label: 'Cursos Oferecidos' },
  { num: '20+', label: 'Anos de História' },
]

export default function Sobre() {
  return (
    <Box sx={{ pt: '68px', minHeight: '100vh', backgroundColor: 'var(--bg)', color: 'var(--text)' }}>
      {/* Header */}
      <Box
        sx={{
          py: { xs: 6, md: 10 },
          px: 3,
          textAlign: 'center',
          background: 'linear-gradient(160deg, #1A1A1A 60%, #2a1500 100%)',
          borderBottom: '2px solid #E87722',
        }}
      >
        <Box component="img" src={logoSrc} alt="IARLEMG" sx={{ height: 80, mb: 3, filter: 'drop-shadow(0 4px 16px rgba(232,119,34,0.4))' }} />
        <Typography variant="h3" fontWeight={800} sx={{ color: '#f5f5f5', fontSize: { xs: '1.8rem', md: '2.5rem' } }}>
          Sobre o{' '}
          <Box component="span" sx={{ color: '#E87722' }}>
            IARLEMG
          </Box>
        </Typography>
        <Typography variant="body1" sx={{ color: '#b0b0b0', mt: 2, maxWidth: 580, mx: 'auto', lineHeight: 1.7 }}>
          Instituto de Educação comprometido com a formação integral dos estudantes, unindo teoria e prática para preparar profissionais do futuro.
        </Typography>
      </Box>

      {/* Números */}
      <Box sx={{ maxWidth: 1100, mx: 'auto', px: 3, py: 6 }}>
        <Grid container spacing={3}>
          {numeros.map((n) => (
            <Grid item xs={6} md={3} key={n.label}>
              <Box
                sx={{
                  textAlign: 'center',
                  p: 3,
                  borderRadius: 3,
                  border: '1px solid #E87722',
                  backgroundColor: 'rgba(232,119,34,0.05)',
                }}
              >
                <Typography variant="h4" fontWeight={800} sx={{ color: '#E87722' }}>
                  {n.num}
                </Typography>
                <Typography variant="body2" sx={{ color: '#b0b0b0', mt: 0.5 }}>
                  {n.label}
                </Typography>
              </Box>
            </Grid>
          ))}
        </Grid>
      </Box>

      {/* Missão/Visão/Valores */}
      <Box sx={{ maxWidth: 1100, mx: 'auto', px: 3, pb: 8 }}>
        <Typography variant="h4" fontWeight={800} textAlign="center" mb={4} sx={{ color: '#f5f5f5' }}>
          Nossa Identidade
        </Typography>
        <Grid container spacing={3}>
          {valores.map((v) => (
            <Grid item xs={12} md={4} key={v.titulo}>
              <Card
                sx={{
                  height: '100%',
                  backgroundColor: '#2a2a2a',
                  border: '1px solid #3a3a3a',
                  borderRadius: 3,
                  transition: 'all 0.25s',
                  '&:hover': { borderColor: '#E87722', transform: 'translateY(-3px)' },
                }}
              >
                <CardContent sx={{ p: 3 }}>
                  <Typography fontSize="2rem" mb={1}>{v.icon}</Typography>
                  <Typography variant="h6" fontWeight={700} sx={{ color: '#E87722', mb: 1 }}>
                    {v.titulo}
                  </Typography>
                  <Typography variant="body2" sx={{ color: '#b0b0b0', lineHeight: 1.7 }}>
                    {v.desc}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Box>
    </Box>
  )
}
