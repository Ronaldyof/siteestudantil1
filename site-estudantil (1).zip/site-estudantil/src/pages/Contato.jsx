import * as React from 'react'
import Box from '@mui/material/Box'
import Typography from '@mui/material/Typography'
import TextField from '@mui/material/TextField'
import Button from '@mui/material/Button'
import Grid from '@mui/material/Grid'
import Alert from '@mui/material/Alert'

const contatos = [
  { icon: '📍', titulo: 'Endereço', desc: 'Rua das Flores, 100 — Centro\nInhumás — GO, Brasil' },
  { icon: '📞', titulo: 'Telefone', desc: '(62) 3000-0000\n(62) 9 0000-0000' },
  { icon: '✉️', titulo: 'E-mail', desc: 'secretaria@iarlemg.edu.br\ndireção@iarlemg.edu.br' },
  { icon: '🕐', titulo: 'Horário', desc: 'Segunda a Sexta\n07h às 21h' },
]

export default function Contato() {
  const [enviado, setEnviado] = React.useState(false)
  const [form, setForm] = React.useState({ nome: '', email: '', mensagem: '' })

  function handleChange(e) {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }))
  }

  function handleSubmit() {
    if (form.nome && form.email && form.mensagem) {
      setEnviado(true)
      setForm({ nome: '', email: '', mensagem: '' })
      setTimeout(() => setEnviado(false), 5000)
    }
  }

  const inputSx = {
    '& .MuiOutlinedInput-root': {
      '& fieldset': { borderColor: '#3a3a3a' },
      '&:hover fieldset': { borderColor: '#E87722' },
      '&.Mui-focused fieldset': { borderColor: '#E87722' },
      color: '#f5f5f5',
      backgroundColor: '#2a2a2a',
    },
    '& .MuiInputLabel-root': { color: '#b0b0b0' },
    '& .MuiInputLabel-root.Mui-focused': { color: '#E87722' },
  }

  return (
    <Box sx={{ pt: '68px', minHeight: '100vh', backgroundColor: 'var(--bg)', color: 'var(--text)' }}>
      {/* Header */}
      <Box
        sx={{
          py: { xs: 6, md: 8 },
          px: 3,
          textAlign: 'center',
          background: 'linear-gradient(160deg, #1A1A1A 60%, #2a1500 100%)',
          borderBottom: '2px solid #E87722',
        }}
      >
        <Typography variant="h3" fontWeight={800} sx={{ color: '#f5f5f5', fontSize: { xs: '1.8rem', md: '2.5rem' } }}>
          Entre em{' '}
          <Box component="span" sx={{ color: '#E87722' }}>Contato</Box>
        </Typography>
        <Typography variant="body1" sx={{ color: '#b0b0b0', mt: 2 }}>
          Estamos aqui para ajudar. Envie sua mensagem ou venha nos visitar.
        </Typography>
      </Box>

      <Box sx={{ maxWidth: 1100, mx: 'auto', px: 3, py: 6 }}>
        <Grid container spacing={5}>
          {/* Informações */}
          <Grid item xs={12} md={5}>
            <Typography variant="h5" fontWeight={700} mb={3} sx={{ color: '#E87722' }}>
              Informações
            </Typography>
            {contatos.map((c) => (
              <Box key={c.titulo} sx={{ display: 'flex', gap: 2, mb: 3 }}>
                <Typography fontSize="1.6rem">{c.icon}</Typography>
                <Box>
                  <Typography fontWeight={700} sx={{ color: '#f5f5f5' }}>{c.titulo}</Typography>
                  <Typography variant="body2" sx={{ color: '#b0b0b0', whiteSpace: 'pre-line', lineHeight: 1.8 }}>
                    {c.desc}
                  </Typography>
                </Box>
              </Box>
            ))}
          </Grid>

          {/* Formulário */}
          <Grid item xs={12} md={7}>
            <Typography variant="h5" fontWeight={700} mb={3} sx={{ color: '#E87722' }}>
              Enviar Mensagem
            </Typography>

            {enviado && (
              <Alert severity="success" sx={{ mb: 2, backgroundColor: 'rgba(232,119,34,0.1)', color: '#f5f5f5', border: '1px solid #E87722' }}>
                Mensagem enviada com sucesso!
              </Alert>
            )}

            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2.5 }}>
              <TextField
                label="Seu nome"
                name="nome"
                value={form.nome}
                onChange={handleChange}
                fullWidth
                sx={inputSx}
              />
              <TextField
                label="Seu e-mail"
                name="email"
                value={form.email}
                onChange={handleChange}
                fullWidth
                sx={inputSx}
              />
              <TextField
                label="Mensagem"
                name="mensagem"
                value={form.mensagem}
                onChange={handleChange}
                multiline
                rows={5}
                fullWidth
                sx={inputSx}
              />
              <Button
                variant="contained"
                size="large"
                onClick={handleSubmit}
                sx={{
                  backgroundColor: '#E87722',
                  '&:hover': { backgroundColor: '#c45e0a' },
                  fontWeight: 700,
                  borderRadius: 3,
                  alignSelf: 'flex-start',
                  px: 4,
                }}
              >
                Enviar Mensagem
              </Button>
            </Box>
          </Grid>
        </Grid>
      </Box>
    </Box>
  )
}
