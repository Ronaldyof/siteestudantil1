import Box from '@mui/material/Box'
import Typography from '@mui/material/Typography'
import Button from '@mui/material/Button'
import Grid from '@mui/material/Grid'
import Card from '@mui/material/Card'
import CardContent from '@mui/material/CardContent'
import { Link } from 'react-router-dom'
import logoSrc from '../assets/logo.png'

const destaques = [
  {
    icon: '📅',
    titulo: 'Calendário Acadêmico',
    desc: 'Datas de matrículas, provas e feriados.',
  },
  {
    icon: '📚',
    titulo: 'Biblioteca',
    desc: 'Acervo, empréstimos e horários.',
  },
  {
    icon: '🎓',
    titulo: 'Cursos',
    desc: 'Técnicos, superiores e formações.',
  },
  {
    icon: '📢',
    titulo: 'Avisos',
    desc: 'Comunicados e atualizações do campus.',
  },
  {
    icon: '👨‍🏫',
    titulo: 'Professores',
    desc: 'Conheça o corpo docente.',
  },
  {
    icon: '🎉',
    titulo: 'Eventos',
    desc: 'Palestras, oficinas e semanas acadêmicas.',
  },
]

export default function Home() {
  return (
    <Box sx={{ pt: '68px', minHeight: '100vh', backgroundColor: 'var(--bg)' }}>
      {/* Hero */}
      <Box
        sx={{
          position: 'relative',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          textAlign: 'center',
          py: { xs: 8, md: 12 },
          px: 3,
          background: 'linear-gradient(160deg, #1A1A1A 60%, #2a1500 100%)',
          borderBottom: '2px solid #E87722',
          overflow: 'hidden',
        }}
      >
        {/* Decorative glow */}
        <Box
          sx={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            width: 500,
            height: 500,
            borderRadius: '50%',
            background: 'radial-gradient(circle, rgba(232,119,34,0.12) 0%, transparent 70%)',
            pointerEvents: 'none',
          }}
        />

        <Box
          component="img"
          src={logoSrc}
          alt="IARLEMG"
          sx={{
            height: { xs: 80, md: 110 },
            mb: 3,
            filter: 'drop-shadow(0 4px 20px rgba(232,119,34,0.5))',
          }}
        />

        <Typography
          variant="h2"
          fontWeight={800}
          sx={{
            fontSize: { xs: '2rem', md: '3rem' },
            color: '#f5f5f5',
            mb: 1,
          }}
        >
          Portal{' '}
          <Box component="span" sx={{ color: '#E87722' }}>
            Estudantil
          </Box>
        </Typography>

        <Typography
          variant="h6"
          sx={{ color: '#b0b0b0', maxWidth: 560, mb: 4, fontWeight: 400, lineHeight: 1.6 }}
        >
          Acesse calendários, avisos, biblioteca e muito mais em um único lugar.
        </Typography>

        <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap', justifyContent: 'center' }}>
          <Button
            component={Link}
            to="/blog"
            variant="contained"
            size="large"
            sx={{
              backgroundColor: '#E87722',
              '&:hover': { backgroundColor: '#c45e0a' },
              fontWeight: 700,
              px: 4,
              borderRadius: 3,
            }}
          >
            Explorar Recursos
          </Button>
          <Button
            component={Link}
            to="/sobre"
            variant="outlined"
            size="large"
            sx={{
              borderColor: '#E87722',
              color: '#E87722',
              '&:hover': { borderColor: '#f59a4f', color: '#f59a4f', backgroundColor: 'rgba(232,119,34,0.06)' },
              fontWeight: 700,
              px: 4,
              borderRadius: 3,
            }}
          >
            Sobre o Campus
          </Button>
        </Box>
      </Box>

      {/* Destaques */}
      <Box sx={{ maxWidth: 1100, mx: 'auto', px: 3, py: 8 }}>
        <Typography
          variant="h4"
          fontWeight={800}
          textAlign="center"
          mb={1}
          sx={{ color: '#f5f5f5' }}
        >
          O que você encontra aqui
        </Typography>
        <Typography variant="body1" textAlign="center" sx={{ color: '#b0b0b0', mb: 5 }}>
          Tudo que o estudante precisa, organizado para você.
        </Typography>

        <Grid container spacing={3}>
          {destaques.map((d) => (
            <Grid item xs={12} sm={6} md={4} key={d.titulo}>
              <Card
                sx={{
                  height: '100%',
                  backgroundColor: '#2a2a2a',
                  border: '1px solid #3a3a3a',
                  borderRadius: 3,
                  transition: 'all 0.25s',
                  cursor: 'default',
                  '&:hover': {
                    borderColor: '#E87722',
                    boxShadow: '0 4px 24px rgba(232,119,34,0.2)',
                    transform: 'translateY(-3px)',
                  },
                }}
              >
                <CardContent sx={{ p: 3 }}>
                  <Typography fontSize="2.2rem" mb={1}>
                    {d.icon}
                  </Typography>
                  <Typography variant="h6" fontWeight={700} sx={{ color: '#f5f5f5', mb: 0.5 }}>
                    {d.titulo}
                  </Typography>
                  <Typography variant="body2" sx={{ color: '#b0b0b0' }}>
                    {d.desc}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Box>

      {/* Footer */}
      <Box
        sx={{
          borderTop: '1px solid #3a3a3a',
          py: 3,
          textAlign: 'center',
        }}
      >
        <Typography variant="body2" sx={{ color: '#666' }}>
          © {new Date().getFullYear()} IARLEMG — Portal Estudantil. Todos os direitos reservados.
        </Typography>
      </Box>
    </Box>
  )
}
