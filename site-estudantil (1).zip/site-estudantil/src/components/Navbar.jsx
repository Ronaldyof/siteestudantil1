import * as React from 'react'
import { Link, useLocation } from 'react-router-dom'
import AppBar from '@mui/material/AppBar'
import Box from '@mui/material/Box'
import Toolbar from '@mui/material/Toolbar'
import IconButton from '@mui/material/IconButton'
import Typography from '@mui/material/Typography'
import Drawer from '@mui/material/Drawer'
import List from '@mui/material/List'
import ListItem from '@mui/material/ListItem'
import ListItemButton from '@mui/material/ListItemButton'
import ListItemText from '@mui/material/ListItemText'
import MenuIcon from '@mui/icons-material/Menu'
import CloseIcon from '@mui/icons-material/Close'
import logoSrc from '../assets/logo.png'

const navLinks = [
  { label: 'Início', to: '/' },
  { label: 'Recursos', to: '/blog' },
  { label: 'Sobre', to: '/sobre' },
  { label: 'Contato', to: '/contato' },
]

export default function Navbar() {
  const [drawerOpen, setDrawerOpen] = React.useState(false)
  const location = useLocation()

  return (
    <>
      <AppBar
        position="fixed"
        elevation={0}
        sx={{
          backgroundColor: '#1A1A1A',
          borderBottom: '2px solid #E87722',
          zIndex: 1300,
        }}
      >
        <Toolbar sx={{ px: { xs: 2, md: 4 }, minHeight: '68px !important' }}>
          {/* Logo + Nome */}
          <Box
            component={Link}
            to="/"
            sx={{
              display: 'flex',
              alignItems: 'center',
              gap: 1.5,
              textDecoration: 'none',
              mr: 'auto',
            }}
          >
            <Box
              component="img"
              src={logoSrc}
              alt="IARLEMG"
              sx={{
                height: 48,
                width: 'auto',
                objectFit: 'contain',
                filter: 'drop-shadow(0 0 6px rgba(232,119,34,0.35))',
              }}
            />
            <Box>
              <Typography
                variant="h6"
                sx={{
                  fontWeight: 800,
                  color: '#E87722',
                  lineHeight: 1.1,
                  letterSpacing: 1,
                  fontSize: { xs: '1rem', md: '1.15rem' },
                }}
              >
                IARLEMG
              </Typography>
              <Typography
                variant="caption"
                sx={{
                  color: '#b0b0b0',
                  letterSpacing: 0.5,
                  fontSize: '0.65rem',
                  display: { xs: 'none', sm: 'block' },
                }}
              >
                Portal Estudantil
              </Typography>
            </Box>
          </Box>

          {/* Desktop Nav Links */}
          <Box sx={{ display: { xs: 'none', md: 'flex' }, gap: 1 }}>
            {navLinks.map((link) => {
              const active = location.pathname === link.to
              return (
                <Box
                  key={link.to}
                  component={Link}
                  to={link.to}
                  sx={{
                    px: 2,
                    py: 0.75,
                    borderRadius: 2,
                    textDecoration: 'none',
                    fontWeight: 600,
                    fontSize: '0.92rem',
                    color: active ? '#E87722' : '#f5f5f5',
                    backgroundColor: active ? 'rgba(232,119,34,0.12)' : 'transparent',
                    border: active ? '1px solid rgba(232,119,34,0.4)' : '1px solid transparent',
                    transition: 'all 0.2s',
                    '&:hover': {
                      color: '#E87722',
                      backgroundColor: 'rgba(232,119,34,0.08)',
                    },
                  }}
                >
                  {link.label}
                </Box>
              )
            })}
          </Box>

          {/* Mobile menu icon */}
          <IconButton
            sx={{ display: { xs: 'flex', md: 'none' }, color: '#E87722' }}
            onClick={() => setDrawerOpen(true)}
          >
            <MenuIcon />
          </IconButton>
        </Toolbar>
      </AppBar>

      {/* Mobile Drawer */}
      <Drawer
        anchor="right"
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        PaperProps={{
          sx: {
            backgroundColor: '#1A1A1A',
            width: 240,
            borderLeft: '2px solid #E87722',
          },
        }}
      >
        <Box sx={{ display: 'flex', justifyContent: 'flex-end', p: 1 }}>
          <IconButton onClick={() => setDrawerOpen(false)} sx={{ color: '#E87722' }}>
            <CloseIcon />
          </IconButton>
        </Box>
        <Box sx={{ display: 'flex', justifyContent: 'center', pb: 2 }}>
          <Box component="img" src={logoSrc} alt="IARLEMG" sx={{ height: 56 }} />
        </Box>
        <List>
          {navLinks.map((link) => {
            const active = location.pathname === link.to
            return (
              <ListItem key={link.to} disablePadding>
                <ListItemButton
                  component={Link}
                  to={link.to}
                  onClick={() => setDrawerOpen(false)}
                  sx={{
                    color: active ? '#E87722' : '#f5f5f5',
                    borderLeft: active ? '3px solid #E87722' : '3px solid transparent',
                    '&:hover': { color: '#E87722', backgroundColor: 'rgba(232,119,34,0.08)' },
                  }}
                >
                  <ListItemText primary={link.label} primaryTypographyProps={{ fontWeight: 600 }} />
                </ListItemButton>
              </ListItem>
            )
          })}
        </List>
      </Drawer>
    </>
  )
}
